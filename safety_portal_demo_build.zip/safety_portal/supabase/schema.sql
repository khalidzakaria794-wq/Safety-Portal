-- Safety Portal initial schema (PostgreSQL / Supabase)
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text,
  preferred_language text not null default 'en' check (preferred_language in ('en','ar')),
  role text not null default 'employee' check (role in ('owner','admin','manager','employee','viewer')),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.modules (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name_en text not null,
  name_ar text not null,
  description_en text default '',
  description_ar text default '',
  icon text not null default 'grid',
  route text not null,
  is_enabled boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.requests (
  id uuid primary key default gen_random_uuid(),
  request_no text unique not null,
  title text not null,
  request_type text not null,
  description text default '',
  status text not null default 'submitted' check (status in ('draft','submitted','under_review','approved','rejected','closed')),
  submitted_by uuid references public.profiles(id),
  assigned_to uuid references public.profiles(id),
  submitted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.audits (
  id uuid primary key default gen_random_uuid(),
  audit_no text unique not null,
  site_name text not null,
  audit_date date not null default current_date,
  auditor_id uuid references public.profiles(id),
  findings_count int not null default 0,
  status text not null default 'open' check (status in ('open','in_progress','completed','closed')),
  notes text default '',
  created_at timestamptz not null default now()
);

create table if not exists public.findings (
  id uuid primary key default gen_random_uuid(),
  finding_no text unique not null,
  audit_id uuid references public.audits(id) on delete set null,
  title text not null,
  risk_level text not null default 'medium' check (risk_level in ('low','medium','high','critical')),
  corrective_action text default '',
  due_date date,
  status text not null default 'open' check (status in ('open','in_progress','resolved','verified')),
  owner_id uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  title text not null,
  body text not null default '',
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_type text not null,
  entity_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Enable RLS. Policies below are a safe starting point; refine before production.
alter table public.profiles enable row level security;
alter table public.modules enable row level security;
alter table public.requests enable row level security;
alter table public.audits enable row level security;
alter table public.findings enable row level security;
alter table public.notifications enable row level security;
alter table public.activity_logs enable row level security;

create policy "Authenticated users can read enabled modules" on public.modules
for select to authenticated using (is_enabled = true);
create policy "Users can read own profile" on public.profiles
for select to authenticated using (id = auth.uid());
create policy "Users can update own profile" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "Users can read own requests" on public.requests
for select to authenticated using (submitted_by = auth.uid() or assigned_to = auth.uid());
create policy "Users can create own requests" on public.requests
for insert to authenticated with check (submitted_by = auth.uid());
create policy "Users can read own notifications" on public.notifications
for select to authenticated using (user_id = auth.uid());
create policy "Users can mark own notifications read" on public.notifications
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Seed initial portal modules
insert into public.modules(code,name_en,name_ar,description_en,description_ar,icon,route,sort_order)
values
('audits','Audits & Inspections','التفتيش والمراجعات','Plan and record safety inspections','تخطيط وتسجيل عمليات التفتيش','clipboard-check','/audits',1),
('findings','Findings','الملاحظات والمخالفات','Track hazards and corrective actions','متابعة المخاطر والإجراءات التصحيحية','alert-triangle','/findings',2),
('risk','Risk Assessment','تقييم المخاطر','Assess and control workplace risks','تقييم مخاطر بيئة العمل والسيطرة عليها','shield','/risk',3),
('permits','Permits to Work','تصاريح العمل','Manage work permits','إدارة تصاريح العمل','file-check','/permits',4),
('training','Training & Talks','التدريب واجتماعات السلامة','Manage training and toolbox talks','إدارة التدريب واجتماعات السلامة','graduation-cap','/training',5),
('requests','Requests','الطلبات','Submit and follow up requests','إنشاء الطلبات ومتابعتها','inbox','/requests',6),
('library','Safety Library','مكتبة السلامة','Access safety documents and procedures','الوصول إلى مستندات وإجراءات السلامة','library','/library',7)
on conflict(code) do nothing;


-- Profile provisioning for new authenticated users.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name, email, preferred_language)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    new.email,
    coalesce(new.raw_user_meta_data ->> 'preferred_language', 'en')
  ) on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Role helpers. These read the caller's profile and avoid trusting client-supplied roles.
create or replace function public.current_user_role()
returns text language sql stable security definer set search_path = '' as $$
  select role from public.profiles where id = auth.uid() and is_active = true limit 1;
$$;

create or replace function public.is_portal_admin()
returns boolean language sql stable security definer set search_path = '' as $$
  select coalesce(public.current_user_role() in ('owner','admin'), false);
$$;

-- Replace starter policies with explicit role-aware policies.
drop policy if exists "Authenticated users can read enabled modules" on public.modules;
drop policy if exists "Admins manage modules" on public.modules;
create policy "Authenticated users can read enabled modules" on public.modules
for select to authenticated using (is_enabled = true or public.is_portal_admin());
create policy "Admins manage modules" on public.modules
for all to authenticated using (public.is_portal_admin()) with check (public.is_portal_admin());

drop policy if exists "Users can read own profile" on public.profiles;
drop policy if exists "Users can update own profile" on public.profiles;
drop policy if exists "Admins read all profiles" on public.profiles;
create policy "Users can read own profile" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_portal_admin());
create policy "Users update own nonprivileged profile fields" on public.profiles
for update to authenticated using (id = auth.uid())
with check (id = auth.uid() and role = public.current_user_role() and is_active = true);
create policy "Admins manage profiles" on public.profiles
for all to authenticated using (public.is_portal_admin()) with check (public.is_portal_admin());

-- Operational records: employees see their own submissions; managers/admins can review all.
drop policy if exists "Users can read own requests" on public.requests;
drop policy if exists "Users can create own requests" on public.requests;
create policy "Read permitted requests" on public.requests
for select to authenticated using (submitted_by = auth.uid() or assigned_to = auth.uid() or public.current_user_role() in ('owner','admin','manager'));
create policy "Create own requests" on public.requests
for insert to authenticated with check (submitted_by = auth.uid());
create policy "Review requests by managers" on public.requests
for update to authenticated using (public.current_user_role() in ('owner','admin','manager')) with check (public.current_user_role() in ('owner','admin','manager'));

-- Audits/findings: authenticated staff may read; authorized roles manage records.
drop policy if exists "Authenticated read audits" on public.audits;
create policy "Authenticated read audits" on public.audits
for select to authenticated using (true);
drop policy if exists "Managers manage audits" on public.audits;
create policy "Managers manage audits" on public.audits
for all to authenticated using (public.current_user_role() in ('owner','admin','manager')) with check (public.current_user_role() in ('owner','admin','manager'));
drop policy if exists "Authenticated read findings" on public.findings;
create policy "Authenticated read findings" on public.findings
for select to authenticated using (true);
drop policy if exists "Managers manage findings" on public.findings;
create policy "Managers manage findings" on public.findings
for all to authenticated using (public.current_user_role() in ('owner','admin','manager')) with check (public.current_user_role() in ('owner','admin','manager'));

-- Activity logs are read-only to portal admins from clients; write privileged logs via trusted server functions.
drop policy if exists "Admins read activity logs" on public.activity_logs;
create policy "Admins read activity logs" on public.activity_logs
for select to authenticated using (public.is_portal_admin());
