const cfg = window.SAFETY_PORTAL_CONFIG || {};
const configured = cfg.SUPABASE_URL?.startsWith('https://') && cfg.SUPABASE_ANON_KEY && !cfg.SUPABASE_URL.includes('YOUR_PROJECT');
const supabase = configured ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;
const $ = (id) => document.getElementById(id);
let importRows = [];

function message(text, error=false) { $('loginMessage').textContent=text; $('loginMessage').style.color=error?'#b42318':''; }
function escapeHtml(v='') { return String(v).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function showLogin(show) { $('loginScreen').classList.toggle('hidden',!show); }
function moduleCard(m) {
  const el=document.createElement('div'); el.className='module';
  el.innerHTML=`<i>▦</i><b>${escapeHtml(m.name_en)}</b><small>${escapeHtml(m.name_ar)}</small><em>${m.is_enabled?'Enabled':'Disabled'}</em><button data-toggle="${m.id}" data-enabled="${m.is_enabled}">${m.is_enabled?'Disable':'Enable'}</button>`;
  return el;
}
async function loadDashboard() {
  if(!supabase) { $('connectionState').textContent='Supabase not configured'; showLogin(true); message('Copy config.example.js to config.js and enter your project URL and anon key.',true); return; }
  const {data:{session}}=await supabase.auth.getSession();
  if(!session){showLogin(true);return;}
  const {data:profile}=await supabase.from('profiles').select('full_name,role,is_active').eq('id',session.user.id).maybeSingle();
  if(!profile || !profile.is_active || !['owner','admin'].includes(profile.role)){await supabase.auth.signOut();showLogin(true);message('This account does not have Control Center administrator access.',true);return;}
  showLogin(false); $('connectionState').textContent='Connected · Supabase'; $('adminEmail').textContent=session.user.email||'Admin';
  const [mods,reqs,finds,users]=await Promise.all([
    supabase.from('modules').select('*').order('sort_order'),
    supabase.from('requests').select('id',{count:'exact',head:true}).not('status','in','(closed,rejected)'),
    supabase.from('findings').select('id',{count:'exact',head:true}).neq('status','verified'),
    supabase.from('profiles').select('id',{count:'exact',head:true}).eq('is_active',true)
  ]);
  if(mods.error){message(mods.error.message,true);return;}
  $('moduleCount').textContent=mods.data.length; $('requestCount').textContent=reqs.count??'—'; $('findingCount').textContent=finds.count??'—'; $('userCount').textContent=users.count??'—';
  $('modules').replaceChildren(...mods.data.map(moduleCard)); $('activityTag').textContent='LIVE DATA';
  $('modules').querySelectorAll('[data-toggle]').forEach(btn=>btn.addEventListener('click',async()=>{
    const enabled=btn.dataset.enabled!=='true'; const {error}=await supabase.from('modules').update({is_enabled:enabled}).eq('id',btn.dataset.toggle);
    if(error) alert(error.message); else await loadDashboard();
  }));
}
$('loginForm').addEventListener('submit',async e=>{e.preventDefault();if(!supabase){message('Supabase is not configured. Follow SETUP.md.',true);return;}message('Signing in…');const {error}=await supabase.auth.signInWithPassword({email:$('email').value,password:$('password').value});if(error)message(error.message,true);else await loadDashboard();});
$('logout').addEventListener('click',async()=>{if(supabase)await supabase.auth.signOut();showLogin(true);});
$('addModule').addEventListener('click',async()=>{
  if(!supabase)return;const nameEn=prompt('Module name (English):');if(!nameEn)return;const nameAr=prompt('اسم الوحدة بالعربية:');if(!nameAr)return;const code=prompt('Unique code (e.g. incident-report):');if(!code)return;
  const {error}=await supabase.from('modules').insert({code:code.trim().toLowerCase(),name_en:nameEn.trim(),name_ar:nameAr.trim(),route:`/${code.trim().toLowerCase()}`,sort_order:99});
  if(error)alert(error.message);else await loadDashboard();
});
$('export').addEventListener('click',async()=>{
  if(!supabase)return;const {data,error}=await supabase.from('modules').select('code,name_en,name_ar,is_enabled,description_en,description_ar,icon,route,sort_order').order('sort_order');if(error){alert(error.message);return;}
  const ws=XLSX.utils.json_to_sheet(data);const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Modules');XLSX.writeFile(wb,'safety-portal-modules.xlsx');
});
$('file').addEventListener('change',async()=>{
  const file=$('file').files[0];$('fileName').textContent=file?.name||'No file selected';importRows=[];$('importNow').disabled=true;$('preview').innerHTML='';if(!file)return;
  try{const bytes=await file.arrayBuffer();const wb=XLSX.read(bytes,{type:'array'});const rows=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{defval:''});
    const required=['code','name_en','name_ar'];if(!rows.length||required.some(k=>!(k in rows[0])))throw new Error('Required columns: code, name_en, name_ar');
    importRows=rows.map(r=>({code:String(r.code).trim().toLowerCase(),name_en:String(r.name_en).trim(),name_ar:String(r.name_ar).trim(),is_enabled:String(r.is_enabled).toLowerCase()!=='false',description_en:String(r.description_en||''),description_ar:String(r.description_ar||''),icon:String(r.icon||'grid'),route:String(r.route||`/${r.code}`),sort_order:Number(r.sort_order||99)}));
    const preview=importRows.slice(0,6);$('preview').innerHTML=`<p>${importRows.length} rows ready. First ${preview.length} shown:</p><table><thead><tr><th>Code</th><th>English</th><th>Arabic</th><th>Enabled</th></tr></thead><tbody>${preview.map(r=>`<tr><td>${escapeHtml(r.code)}</td><td>${escapeHtml(r.name_en)}</td><td>${escapeHtml(r.name_ar)}</td><td>${r.is_enabled?'Yes':'No'}</td></tr>`).join('')}</tbody></table>`;$('importNow').disabled=false;$('importNotice').textContent='Review the preview, then explicitly approve the import.';
  }catch(err){$('importNotice').textContent=err.message;}
});
$('importNow').addEventListener('click',async()=>{if(!importRows.length||!supabase)return;if(!confirm(`Import ${importRows.length} module rows? Existing rows with the same code will be updated.`))return;const {error}=await supabase.from('modules').upsert(importRows,{onConflict:'code'});if(error)alert(error.message);else{alert('Modules imported successfully.');importRows=[];$('importNow').disabled=true;$('preview').innerHTML='';await loadDashboard();}});
if(supabase)supabase.auth.onAuthStateChange(()=>{loadDashboard();});
loadDashboard();
