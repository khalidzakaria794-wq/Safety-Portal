// Copy this file to config.js and enter your Supabase Project URL and anon/publishable key.
// Never put a service_role key in this browser application.
window.SAFETY_PORTAL_CONFIG = {
  SUPABASE_URL: 'https://YOUR_PROJECT_ID.supabase.co',
  SUPABASE_ANON_KEY: 'YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY'
};
